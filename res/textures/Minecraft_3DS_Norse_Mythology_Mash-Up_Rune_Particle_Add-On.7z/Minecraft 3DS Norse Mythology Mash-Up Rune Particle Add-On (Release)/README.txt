Minecraft - New Nintendo 3DS Edition (v1.9.19)
Norse Mythology Mash-Up Rune Particle Add-On Texture Pack

Swap out the floating Standard Galactic Alphabet with the
Elder Futhark Runic System on functioning enchanting tables
found in the Norse Mythology Mash-Up, offering a more cohesive
and immersive Nordic experience.

This add-on is a revision of a particle pack ported from the
Norse Faithful Add-On v1.16.2 Texture Pack.
________________________________________________________________

Original textures by:
Norse Faithful

Ported by:
ThorMode9
________________________________________________________________

Contents:
Norse Mythology Mash-Up Rune Particle Add-On
________________________________________________________________

Instructions:
Place the appropriate contents provided based on your region
into the 'titles' folder on your New Nintendo 3DS/2DS MicroSD
card as shown below:

SD:/luma/titles/00040000001B8700 (USA)
SD:/luma/titles/000400000017CA00 (Europe)
SD:/luma/titles/000400000017FD00 (Japan)

Insert the micro SD into your New Nintendo 3DS/2DS.

To enable game patching, power the system on while holding
'Select' to access the Luma3DS configuration menu. Highlight
'Enable Game Patching' and press 'A' to enable. Press 'Start'
to save the configuration settings.

Open Minecraft - New Nintendo 3DS Edition to access the
updated content.

* Minecraft - New Nintendo 3DS Edition DLC is required to play
Norse Mythology Mash-Up.
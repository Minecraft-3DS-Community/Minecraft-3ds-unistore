This is a New GUI for Minecraft: New Nintendo 3ds.
I (TheRustico36) made this New GUI for Minecraft 3ds. And the twelfth step is from one of DeadskullzJr's instructions lol.

If you're new to Minecraft: New Nintendo 3ds modding, then use these instructions:

- You'll need a Homebrewed 3ds
- And you'll need the game of course

1. Put your 3ds's sd card into your PC.

2. Open it on your PC.

3. Go to Luma (create one foulder with the name luma if you don't have one).

4. Go to titles (create one foulder with the name titles if you don't have one).

5. Go to Minecraft 3ds's title ID. this one depends of the region you're in.(create one foulder with the corresponding title ID if you don't have one)

Title IDs:

00040000001B8700 (USA)
000400000017CA00 (Europe)
000400000017FD00 (Japan)

G:\luma\titles\*Your Region*\romfs\resourcepacks\vanilla\client\textures
                     
6. Go to romfs(create one foulder with the name romfs if you don't have one)

7. Go to resourcepacks (create one foulder with the name resourcepacks if you don't have one)

8. Go to vanilla (create one foulder with the name skins if you don't have one)

9. Go to client (create one foulder with the name skinpacks if you don't have one)

10. Go to textures (create one foulder with the name skinpacks if you don't have one)

11. And put the GUI foulder in there.

12. Safely eject the microSD card, remove the microSD card from your adapter,
then stick said storage card back into your New Nintendo 3DS/2DS XL. Press and
hold Select, power the system on while still holding Select to access the
Luma3DS configuration menu. In here you will want to make sure that "Enable Game
Patching" is set to enabled (indicated by an (x) to the left of the option). Press
Start to save the configuration settings.

13. And now open your game and try your New GUI out.

And if you need help, join the discord Minecraft 3ds Discord or Direct message me:

Discord: https://discord.gg/6JsHyxk3    I, who ported it: TheRustico36#8987
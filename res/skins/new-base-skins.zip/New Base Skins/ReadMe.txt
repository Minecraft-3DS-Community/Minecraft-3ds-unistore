This is a New Base Skin Port for Minecraft: New Nintendo 3ds.
I (TheRustico36) made the 3ds port. All these skins aren't my work. The skin work belongs to Mojang. And the eleventh step is from one of DeadskullzJr's instructions lol.

If you're new to Minecraft: New Nintendo 3ds modding, then use these instructions:

- You'll need a Homebrewed 3ds
- And you'll need the game of course

1. Put your 3ds's sd card into your PC.

2. Open it on your PC.

3. Go to Luma (create one foulder with the name luma if you don't have one).

4. Go to titles (create one foulder with the name titles if you don't have one).

5. Go to Minecraft 3ds's title ID. this one depends of the region you're in.(create one foulder with the corresponding title ID if you don't have one)

Title IDs:

00040000001B8700 (USA)
000400000017CA00 (Europe)
000400000017FD00 (Japan)

6. Go to romfs(create one foulder with the name romfs if you don't have one)

7. Go to resourcepacks (create one foulder with the name resourcepacks if you don't have one)

8. Go to skins (create one foulder with the name skins if you don't have one)

9. Go to skinpacks (create one foulder with the name skinpacks if you don't have one)

10. And put the Base foulder in there.

11. Safely eject the microSD card, remove the microSD card from your adapter,
then stick said storage card back into your New Nintendo 3DS/2DS XL. Press and
hold Select, power the system on while still holding Select to access the
Luma3DS configuration menu. In here you will want to make sure that "Enable Game
Patching" is set to enabled (indicated by an (x) to the left of the option). Press
Start to save the configuration settings.

12. And now open your game and try your skins out.

If you're currently using any custom skin(s) with the use of the Base skinpack, just move it to another skinpack or completly delete it.

I hope you enjoy the pack.

And if you need help, join the discord Minecraft 3ds Discord or Direct message me:

Discord: https://discord.gg/6JsHyxk3    I, who ported it: TheRustico36#8987
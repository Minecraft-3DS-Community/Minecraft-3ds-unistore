In the "Elytra Model" folder you will find the file
you need to replace the 3D model of the Elytra
the 2 files outside of that file are the item
texture.

The "broken_elyta.3dst" and "elytra.3dst" files go in
the items folder, whist the "atlas-blah-blah.3dst" folder
goes in the "atlas folder."
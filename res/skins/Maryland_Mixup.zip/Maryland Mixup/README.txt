Maryland Mixpack
By Duckan - Lucia
Collection of skins

This pack includes 8 skins, and replaces some of the PVP Warrior skins.

Here is a list of them and what skin they replace in-game:

Lucia - Desert_Archer
Kris - Desert_Brawler
Trans Icon Herobrine (with better pants)(by Anon1449) - Desert_Brewer
Trans Icon Herobrine (with better pants) but he is responibly self isolating (by Anon1449) - Desert_Engineer
bicon herobrine (by Anon1449) - Desert_Griefer
Theo (Celeste)(LovelyCelery)- Desert_Hunter
Madeline (Celeste)(LovelyCelery) - Desert_Husk
Badeline (Celeste)(LovelyCelery)- Desert_Tamer

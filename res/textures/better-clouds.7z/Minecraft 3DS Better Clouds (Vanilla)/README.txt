Minecraft - New Nintendo 3DS Edition (v1.9.19)
Better Clouds (for Bedrock Edition)

32x Minecraft 1.16.5 Realistic Texture Pack for Vanilla.
Creates more realistic clouds with color depth and better shape variations.
_______________________________________________________________________________

Original textures by:
Niebieski250

Ported by:
ThorMode9
_______________________________________________________________________________

Contents:
Minecraft 3DS Better Clouds (for Bedrock Edition)
_______________________________________________________________________________

Instructions:
Place the appropriate contents provided based on your region into the "titles"
folder on your New Nintendo 3DS/2DS micro SD card as shown below:

SD:/luma/titles/00040000001B8700 (USA)
SD:/luma/titles/000400000017CA00 (Europe)
SD:/luma/titles/000400000017FD00 (Japan)

Insert the micro SD into your New Nintendo 3DS/2DS.

To enable game patching, power on the system on while holding 'Select' to access the
Luma3DS configuration menu. Highlight "Enable Game Patching" and press 'A' to enable.
Press 'Start' to save the configuration settings.

Open Minecraft - New Nintendo 3DS Edition to access the updated content.
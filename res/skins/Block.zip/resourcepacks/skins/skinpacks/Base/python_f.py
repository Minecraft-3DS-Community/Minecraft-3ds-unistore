with open('steve.3dst','rb+') as f:
    f.seek(0x20)
    datas = f.read()
    lengthOfD = len(datas)
    f.seek(0x20)
    for i in range(lengthOfD):
        f.write(b'\xFF')
